# DemoBankin-App-With-SpringBoot
DemoBanking Application With SpringBoot: 
Please remember to change the Database username and password to your own. 
Also remeber to set your email config to which ever vendor of your choosing as in this project I used HMAILServer to setup emails.
